#!/bin/sh
# Builds identical input under twelve PYTHONHASHSEED values and counts how many
# of the three `## section ...` headings survive into the HTML.
# Expected: 3 every time. Observed with zensical: 2 for roughly half the seeds.
bad=0
for seed in 0 1 2 3 4 5 6 7 8 9 42 99; do
  rm -rf site .cache
  PYTHONHASHSEED=$seed zensical build >/dev/null 2>&1
  n=$(grep -c 'id="section-' site/page/index.html 2>/dev/null || echo 0)
  [ "$n" -ne 3 ] && bad=$((bad + 1))
  printf 'PYTHONHASHSEED=%-3s headings=%s/3\n' "$seed" "$n"
done
printf '\n%s of 12 seeds mis-rendered\n' "$bad"
