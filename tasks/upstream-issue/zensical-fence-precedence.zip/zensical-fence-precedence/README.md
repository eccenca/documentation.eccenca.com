# Reproduction: unstable fenced-code processor precedence

`markdown.extensions.fenced_code` and `pymdownx.superfences` both claim the ```
fence syntax. Only superfences understands the `title="..."` attribute.

Run `sh repro.sh`. Expected `3/3` for every seed. Zensical returns `2/3` for about
half of them: on those runs `fenced_code` wins the fence, the fence never opens, and
the rest of the document -- including the `## section` headings and their anchors --
is emitted as raw text inside a `<pre><code>` block.

`mkdocs build` on the same input returns 3/3 for every seed.

Most projects hit this via `markdown.extensions.extra`, which bundles `fenced_code`.
Bisecting `extra` shows the other six members (abbr, attr_list, def_list, footnotes,
md_in_html, tables) are all clean; `fenced_code` alone reproduces it.
