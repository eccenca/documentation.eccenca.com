TODO CRON example

cd "/mnt/c/Program Files/Splunk/etc/apps/eccenca_poc_investigate/cmem"
