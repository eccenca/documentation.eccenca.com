#!/bin/bash -x
# server
# output_dir_investigation=/opt/cmem-orchestration/data/splunk/tmp/eccenca_poc_investigate/investigation
# output_dir_data=/opt/cmem-orchestration/data/splunk/tmp/eccenca_poc_investigate/data
# local
output_dir_investigation=/mnt/c/tmp/eccenca_poc_investigate/investigation
output_dir_data=/tmp/eccenca_poc_investigate/data

pidFile=${output_dir_investigation}/deleteInvestigation.pid

if [ -f "$pidFile" ] && [ -d "/proc/$(cat $pidFile)" ]; then
        echo "Stop the previous execution has not finished";
else
        echo "Running";
        #save current PID
        echo $$ > ${pidFile}


		cd $output_dir_investigation

		for file in *.del; do
			[ -f "$file" ] || break
			
			id=`cat $file`
			echo $id
			cmemc graph delete --include-imports http://example.com/investigation/${id}
			rm -rf ${output_dir_data}/${id}
			rm ${output_dir_investigation}/investigation_${id}.sh
			rm ${output_dir_investigation}/investigation_${id}.sh.backup
			rm ${output_dir_investigation}/investigation_${id}.del
		done
        rm $pidFile
fi
