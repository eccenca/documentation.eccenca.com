#!/bin/bash -x
# server
#output_dir_investigation=/opt/cmem-orchestration/data/splunk/tmp/eccenca_poc_investigate/investigation
# local
output_dir_investigation=/mnt/c/tmp/eccenca_poc_investigate/investigation

pidFile=${output_dir_investigation}/createInvestigation.pid

if [ -f "$pidFile" ] && [ -d "/proc/$(cat $pidFile)" ]; then
        echo "Stop the previous execution has not finished";
else
        echo "Running";
        #save current PID
        echo $$ > ${pidFile}

        cd $output_dir_investigation

        for file in investigation_*.sh; do
            [ -f "$file" ] || break
            
	    chmod +x $file    
            ./$file
            
            mv $file $file.backup
        done
        rm $pidFile
fi
