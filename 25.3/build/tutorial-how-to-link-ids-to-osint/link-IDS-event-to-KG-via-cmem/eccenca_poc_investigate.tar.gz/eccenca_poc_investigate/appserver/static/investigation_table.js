require([
  // TODO check the dependencies
  'splunkjs/mvc/tableview',
  'splunkjs/mvc/eventsviewerview',
  "splunkjs/mvc/chartview",
  'splunkjs/mvc/searchmanager',
  'splunkjs/mvc',
  'underscore',
  'splunkjs/mvc/simplexml/ready!'
], function (
  TableView,
  EventsViewer,
  ChartView,
  SearchManager,
  mvc,
  _
) {

  var buttonsInvestigationIdColumnHTMLRenderer = TableView.BaseCellRenderer.extend({
    initialize: function (args) {
      // initialize will run once, so we will set up a search and events to be reused.
      this._count = 0
    },
    canRender: function (cell) {
      return _(['buttonsInvestigationId']).contains(cell.field);
    },
    render: function ($td, cell) {
      this._count++;
      let iconTrash = document.createElement("i");
      iconTrash.classList.add("icon-trash");//icon-pencil
      iconTrash.setAttribute("style", "color: red;font-size: x-large;display: flex;");
      let buttonDelete = document.createElement("button");
      //buttonDelete.innerHTML = "Delete";

      buttonDelete.onclick = function () {
        var params = {
          action: "delete",
          //level : "high", 
          investigationID: cell.value
          //sources: []
        }

        console.log(params);
        var service = mvc.createService();
        service.get('/servicesNS/-/eccenca_poc_investigate/investigation', params, function (err, response) {
          if (!err) {
            console.log("Console Log: delete OK");
            //window.location.href = "./investigation_list";
          } else {
            alert("Error")
            console.log(err);
          }
        });
      };
      buttonDelete.append(iconTrash);
      $td.append(buttonDelete);
    }
  });

  var statusColumnHTMLRenderer = TableView.BaseCellRenderer.extend({
    initialize: function (args) {
      // initialize will run once, so we will set up a search and events to be reused.
      this._count = 0
    },
    canRender: function (cell) {
      return _(['status']).contains(cell.field);
    },
    render: function ($td, cell) {
      this._count++;
      if (cell.value === 'https://osint.eccenca.dev/cti#InProgress') {
        let iconClock = document.createElement("i");
        iconClock.classList.add("icon-clock");
        iconClock.setAttribute("style", "color: blue;font-size: x-large;display: flex;");
        $td.append(iconClock);
      } else if (cell.value === 'https://osint.eccenca.dev/cti#Ready') {
        let iconOk = document.createElement("i");
        iconOk.classList.add("icon-check-circle");
        iconOk.setAttribute("style", "color: green;font-size: x-large;display: flex;");
        $td.append(iconOk);
      } else {
        $td.innerText = cell.value;
      }
    }
  });

  Object.keys(mvc.Components.attributes).forEach(id => {
    if (id.includes('investigation_table')) {
      try {
        var tableElement = mvc.Components.getInstance(id);
        tableElement.getVisualization(function (tableView) {
          console.log("on rendered button");
          // Add custom cell renderer, the table will re-render automatically.
          tableView.addCellRenderer(new buttonsInvestigationIdColumnHTMLRenderer());
          tableView.addCellRenderer(new statusColumnHTMLRenderer());
          tableView.on('rendered', function () {
            //console.log("on rendered");
            tableView.$el.find(`th[data-sort-key='buttonsInvestigationId']`).empty();
            // tableView.table.render();
          });
          tableView.render();
        });
      } catch (e) {
        console.log(e);
      }
    }
  });
});