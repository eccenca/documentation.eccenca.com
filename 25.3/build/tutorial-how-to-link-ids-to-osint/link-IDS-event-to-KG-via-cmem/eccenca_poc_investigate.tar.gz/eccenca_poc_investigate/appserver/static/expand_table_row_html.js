require([
    // TODO check the dependencies
    'splunkjs/mvc/tableview',
    'splunkjs/mvc/eventsviewerview',
    "splunkjs/mvc/chartview",
    'splunkjs/mvc/searchmanager',
    'splunkjs/mvc',
    'underscore',
    'splunkjs/mvc/simplexml/ready!'
], function (
    TableView,
    EventsViewer,
    ChartView,
    SearchManager,
    mvc,
    _
) {

    var HideColumnHTMLRenderer = TableView.BaseCellRenderer.extend({
        canRender: function (cell) {
            return _(['html']).contains(cell.field);
        },
        render: function ($td, cell) {
            $td.hide()
        }
    });

    var HTMLRowExpansionRenderer = TableView.BaseRowExpansionRenderer.extend({
        initialize: function (args) {
            // initialize will run once, so we will set up a search and events to be reused.
            // this._searchManager = new SearchManager({
            //     id: 'details-search-manager',
            //     preview: false
            // });
            // this.chartViewer = new ChartView({
            //     type: "bar",
            //     managerid: 'details-search-manager'
            // });
        },
        canRender: function (rowData) {
            // Since more than one row expansion renderer can be registered we let each decide if
            // they can handle that data
            // Here we will always handle it.
            return true;
        },
        render: function ($container, rowData) {
            var htmlCell = _(rowData.cells).find(function (cell) {
                return cell.field === 'html';
            });
            // console.log(htmlCell.value);

            let div = document.createElement("div");

            // div.classList.add("panel-body","html");
            div.innerHTML = htmlCell.value;

            $container.append(div);
            $container.find("a").on("click", function (e) {
                // Prevent drilldown from redirecting away from the page
                e.preventDefault();

                // // Console feedback
                // console.log("Click");

                // // Use jQuery to fill in the text in the HTML's <div> tag
                // //$('#message').text("Clicked!");

                window.open($(this).attr('href'), $(this).attr('target')).focus();
            });
        }
    });

    Object.keys(mvc.Components.attributes).forEach(id => {
        if (id.includes('expand_table_row_html')) {
            var tableElement = mvc.Components.getInstance(id);
            try {
                tableElement.getVisualization(function (tableView) {
                    // Add custom cell renderer, the table will re-render automatically.
                    tableView.addRowExpansionRenderer(new HTMLRowExpansionRenderer());
                    tableView.addCellRenderer(new HideColumnHTMLRenderer());
                    tableView.on('rendered', function () {
                        // console.log("on rendered");
                        tableView.$el.find(`[data-sort-key='html']`).remove();
                        // tableView.table.render();
                    });
                    tableView.render();
                });
            } catch (e) {
                console.log(e);
            }
        }
    });
});