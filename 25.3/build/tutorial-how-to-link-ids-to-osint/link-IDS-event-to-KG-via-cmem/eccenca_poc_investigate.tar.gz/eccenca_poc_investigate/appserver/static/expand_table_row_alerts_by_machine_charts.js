
require.config({
  paths: {
    d3: "../app/eccenca_poc_investigate/node_modules/d3/dist/d3"
  }
});
require([
  // TODO check the dependencies
  'splunkjs/mvc/tableview',
  'splunkjs/mvc/eventsviewerview',
  "splunkjs/mvc/chartview",
  'splunkjs/mvc/searchmanager',
  'splunkjs/mvc',
  'underscore',
  'splunkjs/mvc/simplexml/ready!',
  'd3'
], function (
  TableView,
  EventsViewer,
  ChartView,
  SearchManager,
  mvc,
  _
) {
  var d3 = require("d3");

  var PiechartColumnHTMLRenderer = TableView.BaseCellRenderer.extend({
    initialize: function (args) {
      // initialize will run once, so we will set up a search and events to be reused.
      this._count = 0
    },
    canRender: function (cell) {
      return _(['Context']).contains(cell.field) || _(['Level']).contains(cell.field);
    },
    render: function ($td, cell) {
      this._count++;
      let id = "cellChart" + this._count;
      // Step 3
      let width = 100,
        height = 100,
        radius = 50;
      let svg = d3.select($td[0])
        .append("svg")
        .attr('width', 200)
        .attr('height', height);
      // Step 1       

      let data = JSON.parse(cell.value);
      // var data = [{label: "System", value: 20.70,color: "#0f7eb3"}, 
      //             {label: "Network", value: 30.92,color: "#b3440f"}];

      var color = [];
      for (var i = 0; i < data.length; i++) {
        color.push(data[i].color);
      }

      var g = svg.append("g")
        .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

      // Step 4
      var ordScale = d3.scaleOrdinal()
        .domain(data)
        .range(color);

      // Step 5
      var pie = d3.pie().value(function (d) {
        return d.value;
      });

      var arc = g.selectAll("arc")
        .data(pie(data))
        .enter();

      // Step 6
      var path = d3.arc()
        .outerRadius(radius)
        .innerRadius(0);

      arc.append("path")
        .attr("d", path)
        .attr("fill", function (d) { return ordScale(d.data.label); });

      // Step 7
      let lineHeight = 35;
      for (var i = 0; i < data.length; i++) {
        svg.append("circle").attr("cx", 110).attr("cy", lineHeight * (i + 1)).attr("r", 6)
          .style("fill", data[i].color);
          svg.append("text").attr("x", 120).attr("y", lineHeight * (i + 1)).text(data[i].label)
            .style("font-size", "15px").attr("alignment-baseline", "middle");
            svg.append("text").attr("x", 120).attr("y", 15 + lineHeight * (i + 1)).text(data[i].value)
              .style("font-size", "15px").attr("alignment-baseline", "middle");
      }
    }
  });

  console.log("load script ComputerSelectedColorRowRenderer");
  var ComputerSelectedColorRowRenderer = TableView.BaseCellRenderer.extend({
    initialize: function (args) {
    },
    canRender: function (cell) {
      //?computer ?Computer_name
      return _(['Computer_name']).contains(cell.field);
    },
    render: function ($td, cell) {
        if( cell.value.includes(mvc.Components.get("default").get("computer"))) {
          $td.css('background','#fd000012')
        }
        $td.html(cell.value.replace(/ \([^\)]*\)/g, ""));
    }
  });

  Object.keys(mvc.Components.attributes).forEach(id => {
    if (id.includes('expand_table_row_alerts_by_machine_charts')) {
      var tableElement = mvc.Components.getInstance(id);
      try {
        tableElement.getVisualization(function (tableView) {
          console.log("on rendered barchart");
          // Add custom cell renderer, the table will re-render automatically.
          //tableView.addCellRenderer(new BarchartColumnHTMLRenderer());
          tableView.addCellRenderer(new PiechartColumnHTMLRenderer());
          tableView.addCellRenderer(new ComputerSelectedColorRowRenderer());
          tableView.render();
        });
      } catch (e) {
        console.log(e);
      }
    }
  });
});