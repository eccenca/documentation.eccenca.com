require.config({
  paths: {
    d3: "../app/eccenca_poc_investigate/node_modules/d3/dist/d3"
  }
});
require([
  // TODO check the dependencies
  'splunkjs/mvc/tableview',
  'splunkjs/mvc/eventsviewerview',
  "splunkjs/mvc/chartview",
  'splunkjs/mvc/searchmanager',
  'splunkjs/mvc',
  'underscore',
  'splunkjs/mvc/simplexml/ready!',
  'd3'
], function (
  TableView,
  EventsViewer,
  ChartView,
  SearchManager,
  mvc,
  _
) {
  var d3 = require("d3");

  var alertColorRowRenderer = TableView.BaseCellRenderer.extend({
    initialize: function (args) {
      // initialize will run once, so we will set up a search and events to be reused.
      this._count = 0
    },
    canRender: function (cell) {
      return _(['Level']).contains(cell.field);
    },
    render: function ($td, cell) {
      let color = '';
      switch (cell.value) {
        case 'https://osint.eccenca.dev/cti#high':
          color = '#FF0000';
          break;
        case 'https://osint.eccenca.dev/cti#med':
          color = '#F98506';
          break;
        case 'https://osint.eccenca.dev/cti#low':
          color = '#FFE40E';
          break;
        default: //'https://osint.eccenca.dev/cti#info':
          color = '#3500FF';
      }
      $td.css('background', color);
    }
  });
  var contextColorRowRenderer = TableView.BaseCellRenderer.extend({
    initialize: function (args) {
      // initialize will run once, so we will set up a search and events to be reused.
      this._count = 0
    },
    canRender: function (cell) {
      return _(['Context']).contains(cell.field);
    },
    render: function ($td, cell) {
      let color = '';
      switch (cell.value) {
        case 'https://osint.eccenca.dev/cti#EventZeekNotice':
          color = '#C004D9';
          break;
        case 'https://osint.eccenca.dev/cti#EventHayabusa':
          color = '#78A64B';
          break;
      }
      $td.css('background', color);
    }
  });

  Object.keys(mvc.Components.attributes).forEach(id => {
    if (id.includes('expand_table_row_alert_level')) {
      var tableElement = mvc.Components.getInstance(id);
      try {
        tableElement.getVisualization(function (tableView) {
          // console.log("on rendered row_alert_level");
          tableView.addCellRenderer(new alertColorRowRenderer());
          tableView.addCellRenderer(new contextColorRowRenderer());
          tableView.render();
        });
      } catch (e) {
        console.log(e);
      }
    }
  });

});