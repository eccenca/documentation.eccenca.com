require([
    // TODO check the dependencies
    'splunkjs/mvc/tableview',
    'splunkjs/mvc/eventsviewerview',
    "splunkjs/mvc/chartview",
    'splunkjs/mvc/searchmanager',
    'splunkjs/mvc',
    'underscore',
    'splunkjs/mvc/simplexml/ready!'
], function (
    TableView,
    EventsViewer,
    ChartView,
    SearchManager,
    mvc,
    _
) {


    var ComputerLinkRenderer = TableView.BaseCellRenderer.extend({

        canRender: function (cell) {
            return  _(['Nom_d_hote_source']).contains(cell.field)
             ||_(['Nom_d_hote_destination']).contains(cell.field)
        },
        render: function ($td, cellData) {            
            $td.html(cellData.value);
            $td.find("a").on("click", function (e) {
                e.preventDefault();
                window.open($(this).attr('href'), $(this).attr('target')).focus();
            });
        }
    });

    Object.keys(mvc.Components.attributes).forEach(id => {
        if (id.includes('expand_table_row_link_investigation_highlevel')) {
            var tableElement = mvc.Components.getInstance(id);
            try {
                tableElement.getVisualization(function (tableView) {
                    tableView.addCellRenderer(new ComputerLinkRenderer());
                    tableView.render();
                });
            } catch (e) {
                console.log(e);
            }
        }
    });
});