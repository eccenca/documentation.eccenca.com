require([
    "splunkjs/mvc",
    "splunkjs/mvc/simplexml/ready!"
], function (mvc) {

    console.log("load script investigations");
    $(function () {
        $(".buttonInvestigationCreateHighLevel").on("click", function (e) {
            e.preventDefault();
            console.log("Console Log: investigationhighlevel/start");
            var params = {
                action: "create",
                level: "high",
                sources: [],
                inferences: "",
                indexes: "",
                investigationHighLevelId: ""
            }

            var defaultTokenModel = mvc.Components.get("default");

            Object.keys(defaultTokenModel.attributes).forEach(key => {
                if (key.startsWith('source_')) {
                    console.log(defaultTokenModel.get(key));
                    params.sources.push(defaultTokenModel.get(key));
                }else if (key == 'inferences') {
                    console.log(defaultTokenModel.get(key));
                    params.inferences = defaultTokenModel.get(key);
                }else if (key == 'indexCombobox') {
                    console.log(defaultTokenModel.get(key));
                    params.indexes = defaultTokenModel.get(key);
                }
            });
            console.log(params);

            var service = mvc.createService();
            //https://localhost:8089/servicesNS/-/eccenca_poc_investigate/investigation
            service.get('/servicesNS/-/eccenca_poc_investigate/investigation', params, function (err, response) {
                if (!err) {
                    console.log("Console Log: OK");
                    window.location.href = "./investigation_list";
                } else {
                    alert("Error")
                    console.log(err);
                }
            });
        });

        $(".buttonInvestigationCreateLowLevel").on("click", function (e) {
            e.preventDefault();
            console.log("Console Log: investigationlowlevel/start");
            var params = {
                action: "create",
                level: "low",
                sources: [],
                inferences: "",
                investigationHighLevelId: ""
            }

            var defaultTokenModel = mvc.Components.get("default");

            Object.keys(defaultTokenModel.attributes).forEach(key => {
                if (key.startsWith('source_')) {
                    console.log(defaultTokenModel.get(key));
                    params.sources.push(defaultTokenModel.get(key));
                }else if (key == 'inferences') {
                    console.log(defaultTokenModel.get(key));
                    params.inferences = defaultTokenModel.get(key);
                }else if (key == 'form.investigationHighLevelId') {
                    console.log(defaultTokenModel.get(key));
                    params.investigationHighLevelId = defaultTokenModel.get(key);
                }
            });
            console.log(params);

            var service = mvc.createService();
            //https://localhost:8089/servicesNS/-/eccenca_poc_investigate/investigation
            service.get('/servicesNS/-/eccenca_poc_investigate/investigation', params, function (err, response) {
                if (!err) {
                    console.log("Console Log: OK");
                    window.location.href = "./investigation_list";
                } else {
                    alert("Error")
                    console.log(err);
                }
            });
        });
        
        $(".buttonOpenRequestInvestigationLowLevel").on("click", function (e) {
            e.preventDefault();
            console.log("Console Log: investigationlowlevel/request");

            let defaultTokenModel = mvc.Components.get("default");
            let investigationId = defaultTokenModel.get("form.investigationId");
            let earliest = defaultTokenModel.get("investigation_lowlevel_selection_earliest");
            let latest = defaultTokenModel.get("investigation_lowlevel_selection_latest");
            let link = "./investigation_low-level_request?";
            link += "form.investigationHighLevelId="+investigationId;
            link += "&form.timeInput.earliest="+earliest;
            link += "&form.timeInput.latest="+latest;

            window.open(link, '_blank');
        });
    });
});