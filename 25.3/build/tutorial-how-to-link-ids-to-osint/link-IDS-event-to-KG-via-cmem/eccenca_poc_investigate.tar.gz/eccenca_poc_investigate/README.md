# Investigate lateral movements with a knowledge graph

## Dependency

This app uses the SPARQL command in the app "Linked Data App" (eccenca_commands). You can install it via the Splunk marketplace or via this archive in the tutorial "Tutorial: how to link Intrusion Detection Systems (IDS) to Open-Source INTelligence (OSINT)" in the [documentation of eccenca](https://documentation.eccenca.com/23.1/tutorials/).

##  Create the folders for the generated scripts and the imported data of Splunk

For example:
```bash
mkdir -p /opt/cmem-orchestration/data/splunk/tmp/eccenca_poc_investigate/investigation
mkdir -p /opt/cmem-orchestration/data/splunk/tmp/eccenca_poc_investigate/data
```

## Configure the app with these folders

Copy the file and modify it:

```bash
cp default/settings_template.conf default/settings.conf
vi default/settings.conf
```
And modify the folders.

## Configure the scripts for CMEMC

In the folder cmem, modify the folders in parameters to execute the generated scripts.

## Installation via the repository

### Copy the app in Splunk

Via the files: clone the project `eccenca_poc_investigate` in the folder splunk/etc/apps of Splunk.

### Dependencies for Python

Installation of Dependencies:
```bash
    cd eccenca_poc_investigate
    pip install splunk-sdk  -t bin
```

## Things to know during the development

Refresh the javascript and static Web files with this link:
- http://127.0.0.1:8000/en-US/debug/refresh (local)

To see logs of dashboards (javascript), you need to open the inspect tools of navigator.

Refresh the python scripts:
- Option 1: Restart the server Splunk or
- Option 2: Disable all the caches: https://dev.splunk.com/enterprise/docs/developapps/manageknowledge/assetcaching/

Enable DEBUG in the log for Python (doesn't work with the commands):
https://docs.splunk.com/Documentation/Splunk/9.0.1/Troubleshooting/Enabledebuglogging

See logs of endpoint "Investigation":
Powershell

    Get-Content "C:\Program Files\Splunk\var\log\splunk\python.log" -Wait -Tail 30 | Select-String Investigation  

Linux

    tail -f /opt/cmem-orchestration/data/splunk/var/log/splunk/python.log | grep Investigation

## Package for Splunk

tar  --exclude-vcs  --exclude='default/*old*' --exclude='bin/*old*' -zcvf eccenca_poc_investigate.tar.gz eccenca_poc_investigate/